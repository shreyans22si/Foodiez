//
//  MainNavigationController.swift
//  Foodiez
//
//  Created by Tilakbhai Suthar on 2019-12-02.
//  Copyright © 2019 Jay Shah. All rights reserved.
//

import Foundation
import UIKit

class MainNavigationController: UINavigationController
{
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
