//
//  ViewController.swift
//  Foodiez
//
//  Created by Jay Shah on 2019-11-22.
//  Copyright © 2019 Jay Shah. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        // The persistent container is available.
       // core data Truncate
        
    }
}
